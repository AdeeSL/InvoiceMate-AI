# InvoiceMate AI
Open-source local-first invoice and receipt assistant.

## Features
- Upload PDF/image receipts and invoices
- OCR using PaddleOCR
- Structure extracted text using local Ollama + Qwen2.5
- Review/edit fields before saving
- SQLite storage, search and CSV export

## Stack
React + Vite, FastAPI, PaddleOCR, PyMuPDF, Ollama (`qwen2.5:3b`), SQLite, Docker.

## Run with Docker
```bash
docker compose up --build -d
docker exec -it invoicemate-ollama ollama pull qwen2.5:3b
```
Open http://localhost:5173.

## Run without Docker
1. Install Ollama and run `ollama pull qwen2.5:3b`.
2. Backend:
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```
3. Frontend:
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173.

Copy `backend/.env.example` to `backend/.env` to customize settings.

## API
- `GET /api/health`
- `GET /api/model`
- `POST /api/extract` (multipart file)
- `POST /api/extract-text` (JSON: `{"text":"..."}`)
- `POST /api/invoices`
- `GET /api/invoices?search=...`
- `GET /api/export.csv`

## GitHub
Create `invoicemate-ai` on GitHub, then:
```bash
git init
git add .
git commit -m "Initial InvoiceMate AI MVP"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/invoicemate-ai.git
git push -u origin main
```

## Important
This is an MVP, not accounting/tax software. OCR and AI can make mistakes: verify every field before saving. No authentication or multi-user isolation is included. Do not expose it publicly with real financial data until you add authentication, authorization, HTTPS, backups, rate limiting, file scanning, tenant isolation and secure retention. Local inference avoids sending documents to a commercial AI API, but hardware and operating costs still apply.

MIT License.
