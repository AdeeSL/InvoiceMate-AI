import csv,io,httpx
from fastapi import FastAPI,UploadFile,File,HTTPException,Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from .config import CORS_ORIGINS,MAX_UPLOAD_MB,OLLAMA_URL,OLLAMA_MODEL
from .db import init_db,save,listing
from .ocr import extract
from .ai import parse
app=FastAPI(title="InvoiceMate AI API",version="1.0.0")
app.add_middleware(CORSMiddleware,allow_origins=CORS_ORIGINS,allow_methods=["*"],allow_headers=["*"])
@app.on_event("startup")
def startup(): init_db()
class Invoice(BaseModel):
    supplier:str|None=None; invoice_number:str|None=None; invoice_date:str|None=None; due_date:str|None=None
    currency:str|None="LKR"; subtotal:float|None=None; tax:float|None=None; total:float|None=None
    category:str="Other"; description:str|None=None; raw_text:str|None=None
@app.get("/api/health")
def health(): return {"status":"ok"}
@app.get("/api/model")
async def model():
    try:
        async with httpx.AsyncClient(timeout=3) as c: r=await c.get(f"{OLLAMA_URL}/api/tags"); r.raise_for_status()
        return {"available":True,"model":OLLAMA_MODEL,"installed_models":[x.get("name") for x in r.json().get("models",[])]}
    except Exception: return {"available":False,"model":OLLAMA_MODEL,"installed_models":[]}
@app.post("/api/extract")
async def extract_file(file:UploadFile=File(...)):
    data=await file.read()
    if len(data)>MAX_UPLOAD_MB*1024*1024: raise HTTPException(413,f"Maximum upload size is {MAX_UPLOAD_MB} MB")
    name=file.filename or "upload"
    if not name.lower().endswith((".pdf",".png",".jpg",".jpeg",".webp")): raise HTTPException(400,"Use PDF, PNG, JPG or WEBP")
    try:
        text=extract(name,data); return {"data":await parse(text),"raw_text":text}
    except Exception as e: raise HTTPException(502,str(e))
@app.post("/api/extract-text")
async def extract_text(body:dict):
    try:
        text=str(body.get("text","")); return {"data":await parse(text),"raw_text":text}
    except Exception as e: raise HTTPException(502,str(e))
@app.post("/api/invoices")
def create(invoice:Invoice): return save(invoice.model_dump())
@app.get("/api/invoices")
def get(q:str=Query(default="",max_length=100)): return listing(q)
@app.get("/api/export.csv")
def export():
    rows=listing(); out=io.StringIO()
    cols=["id","supplier","invoice_number","invoice_date","due_date","currency","subtotal","tax","total","category","description","created_at"]
    w=csv.DictWriter(out,fieldnames=cols); w.writeheader(); w.writerows(rows); out.seek(0)
    return StreamingResponse(iter([out.getvalue()]),media_type="text/csv",headers={"Content-Disposition":"attachment; filename=invoicemate-invoices.csv"})
