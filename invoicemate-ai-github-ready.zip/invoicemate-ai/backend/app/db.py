import sqlite3
from datetime import datetime,timezone
from .config import DATABASE_PATH
FIELDS=["supplier","invoice_number","invoice_date","due_date","currency","subtotal","tax","total","category","description","raw_text"]
def db():
    c=sqlite3.connect(DATABASE_PATH); c.row_factory=sqlite3.Row; return c
def init_db():
    with db() as c:
        c.execute('''CREATE TABLE IF NOT EXISTS invoices (
        id INTEGER PRIMARY KEY AUTOINCREMENT, supplier TEXT, invoice_number TEXT,
        invoice_date TEXT, due_date TEXT, currency TEXT, subtotal REAL, tax REAL,
        total REAL, category TEXT, description TEXT, raw_text TEXT, created_at TEXT)''')
def save(data):
    vals=[data.get(k) for k in FIELDS]
    with db() as c:
        cur=c.execute(f"INSERT INTO invoices ({','.join(FIELDS)},created_at) VALUES ({','.join(['?']*len(FIELDS))},?)", vals+[datetime.now(timezone.utc).isoformat()])
        return dict(c.execute("SELECT * FROM invoices WHERE id=?",(cur.lastrowid,)).fetchone())
def listing(q=""):
    with db() as c:
        if q:
            rows=c.execute("SELECT * FROM invoices WHERE supplier LIKE ? OR invoice_number LIKE ? OR category LIKE ? ORDER BY id DESC",(f"%{q}%",)*3).fetchall()
        else: rows=c.execute("SELECT * FROM invoices ORDER BY id DESC").fetchall()
        return [dict(x) for x in rows]
