import json,httpx
from .config import OLLAMA_URL,OLLAMA_MODEL
PROMPT='''Extract invoice data from supplied OCR text. Return ONLY JSON. Never invent missing values; use null. Schema: {"supplier":string|null,"invoice_number":string|null,"invoice_date":string|null,"due_date":string|null,"currency":string|null,"subtotal":number|null,"tax":number|null,"total":number|null,"category":string,"description":string}. Dates YYYY-MM-DD if possible. Category one of Office Supplies, Travel, Meals, Utilities, Software, Equipment, Marketing, Professional Services, Other.'''
async def parse(text):
    if not text.strip(): raise ValueError("No text extracted. Use a clearer scan or paste text manually.")
    body={"model":OLLAMA_MODEL,"stream":False,"format":"json","messages":[{"role":"system","content":PROMPT},{"role":"user","content":text[:18000]}],"options":{"temperature":0}}
    async with httpx.AsyncClient(timeout=120) as c:
        r=await c.post(f"{OLLAMA_URL}/api/chat",json=body); r.raise_for_status()
    content=r.json().get("message",{}).get("content","{}")
    try: data=json.loads(content)
    except json.JSONDecodeError:
        a,b=content.find("{"),content.rfind("}")
        if a<0 or b<=a: raise ValueError("AI returned invalid JSON; please retry.")
        data=json.loads(content[a:b+1])
    data["raw_text"]=text
    return data
