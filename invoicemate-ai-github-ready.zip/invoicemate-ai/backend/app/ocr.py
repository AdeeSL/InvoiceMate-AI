import io
from PIL import Image
import fitz
_engine=None
def engine():
    global _engine
    if _engine is None:
        from paddleocr import PaddleOCR
        _engine=PaddleOCR(use_angle_cls=True,lang="en",show_log=False)
    return _engine
def extract(filename,content):
    pages=[]
    if filename.lower().endswith(".pdf"):
        doc=fitz.open(stream=content,filetype="pdf")
        pages=[Image.open(io.BytesIO(p.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False).tobytes("png"))).convert("RGB") for p in doc]
    else: pages=[Image.open(io.BytesIO(content)).convert("RGB")]
    lines=[]
    for image in pages:
        result=engine().ocr(image,cls=True)
        for page in result or []:
            for item in page or []: lines.append(item[1][0])
    return "\n".join(lines)
