import os
from pathlib import Path
from dotenv import load_dotenv
load_dotenv()
OLLAMA_URL=os.getenv("OLLAMA_URL","http://localhost:11434").rstrip("/")
OLLAMA_MODEL=os.getenv("OLLAMA_MODEL","qwen2.5:3b")
DATABASE_PATH=os.getenv("DATABASE_PATH","./data/invoicemate.db")
CORS_ORIGINS=[x.strip() for x in os.getenv("CORS_ORIGINS","http://localhost:5173").split(",") if x.strip()]
MAX_UPLOAD_MB=int(os.getenv("MAX_UPLOAD_MB","15"))
Path(DATABASE_PATH).parent.mkdir(parents=True,exist_ok=True)
